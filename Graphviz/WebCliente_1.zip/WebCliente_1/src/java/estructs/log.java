/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructs;

/**
 *
 * @author Luiskr
 */
public class log {
    
    public String getUser(){
        
        return "admin";
    }
    
    public String getPassword(){
        return "admin";
    }
}
